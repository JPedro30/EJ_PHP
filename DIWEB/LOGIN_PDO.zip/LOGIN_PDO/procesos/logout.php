<?php
session_start();
session_destroy();
$_SESSION = [];
header('Location: ../vistas/inicio.html');
exit();
?>