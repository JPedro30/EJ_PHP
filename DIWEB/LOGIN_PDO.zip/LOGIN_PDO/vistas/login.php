<?php
session_start();

$mensaje = $_SESSION['mensaje'] ?? null;
$permitir_acceso = $_SESSION['permitir_acceso'] ?? null;
$sesion_iniciada = $_SESSION['sesion_iniciada'] ?? null;
$rol = $_SESSION['rol'] ?? null;

unset($_SESSION['mensaje']);
unset($_SESSION['permitir_acceso']);

// Redirección ANTES de cualquier salida de texto/HTML
if ($sesion_iniciada !== null && $rol !== null) {
    switch ($rol) {
        case 'A':
            header("Location: ../vistas/dashboard_admin.php");
            break;
        case 'T':
            header("Location: ../vistas/dashboard_trabajador.php");
            break;
        case 'C':
            header("Location: ../vistas/dashboard_cliente.php");
            break;
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../estilo/style.css">
</head>

<body class="bg-slate-900 min-h-screen flex flex-col items-center justify-center p-4">

    <div class="max-w-sm w-full space-y-4">
        <a href="../vistas/inicio.html" class="btn-back">Volver al inicio</a>

        <div class="bg-slate-200 p-8 rounded-2xl shadow-sm border border-slate-200">
            <h1 class="text-2xl font-bold text-slate-800 text-center mb-6">Inicio de Sesión</h1>

            <?php if ($mensaje): ?>
                <div class="bg-red-50 text-red-700 p-3 rounded-lg text-sm mb-4 border border-red-200">
                    <?= htmlspecialchars($mensaje) ?>
                </div>
            <?php endif; ?>

            <form id="formLogin" action="../procesos/procesoLogin.php" method="post" class="space-y-4">
                <div class="form-group">
                    <label class="form-label">Correo electrónico</label>
                    <input type="email" name="email" class="form-input" placeholder="tu@email.com" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Contraseña</label>
                    <input type="password" name="password" class="form-input" placeholder="••••••••" required>
                </div>

                <input type="hidden" name="latitud" id="latitud">
                <input type="hidden" name="longitud" id="longitud">

                <button type="submit" id="btnSubmit" class="btn-primary opacity-50 cursor-not-allowed" disabled>
                    Obteniendo ubicación...
                </button>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const btnSubmit = document.getElementById('btnSubmit');
            const latInput = document.getElementById('latitud');
            const lngInput = document.getElementById('longitud');

            function obtenerUbicacion() {
                if (!navigator.geolocation) {
                    alert("Tu navegador no soporta geolocalización.");
                    return;
                }

                navigator.geolocation.getCurrentPosition(
                    function(position) {
                        latInput.value = position.coords.latitude;
                        lngInput.value = position.coords.longitude;

                        btnSubmit.disabled = false;
                        btnSubmit.innerText = "ENTRAR";
                        btnSubmit.classList.remove('opacity-50', 'cursor-not-allowed');
                    },
                    function(error) {
                        console.warn("Error de geolocalización (" + error.code + "): " + error.message);

                        let msg = "No se ha podido obtener tu ubicación actual.";
                        if (error.code === error.PERMISSION_DENIED) {
                            msg = "Has denegado el permiso de ubicación en el navegador.";
                        } else if (error.code === error.TIMEOUT) {
                            msg = "Se agotó el tiempo de espera al consultar la ubicación. Revisa la configuración de ubicación de tu sistema operativo.";
                        }

                        alert(msg);
                        btnSubmit.innerText = "Ubicación requerida";
                    }, {
                        enableHighAccuracy: false, // Desactivar alta precisión para evitar fallos en PC
                        timeout: 15000, // 15 segundos de margen
                        maximumAge: 60000 // Aceptar última posición conocida de los últimos 60s
                    }
                );
            }

            obtenerUbicacion();
        });
    </script>
</body>

</html>